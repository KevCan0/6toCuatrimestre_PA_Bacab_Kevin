<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc(), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Usuario no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = '%' . trim($_GET['nombre']) . '%';
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE nombre LIKE ? ORDER BY id");
            $stmt->bind_param("s", $nombre);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();
            while ($row = $resultado->fetch_assoc()) { $usuarios[] = $row; }
            http_response_code(200);
            echo json_encode($usuarios, JSON_UNESCAPED_UNICODE);
            $stmt->close();
        } elseif (isset($_GET['correo'])) {
            $correo = trim($_GET['correo']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE correo = ?");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();
            while ($row = $resultado->fetch_assoc()) { $usuarios[] = $row; }
            http_response_code(200);
            echo json_encode($usuarios, JSON_UNESCAPED_UNICODE);
            $stmt->close();
        } elseif (isset($_GET['id_rol'])) {
            $id_rol = intval($_GET['id_rol']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id_rol = ? ORDER BY id");
            $stmt->bind_param("i", $id_rol);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();
            while ($row = $resultado->fetch_assoc()) { $usuarios[] = $row; }
            http_response_code(200);
            echo json_encode($usuarios, JSON_UNESCAPED_UNICODE);
            $stmt->close();
        } else {
            $resultado = $conn->query("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios ORDER BY id");
            $usuarios = array();
            while ($row = $resultado->fetch_assoc()) { $usuarios[] = $row; }
            http_response_code(200);
            echo json_encode($usuarios, JSON_UNESCAPED_UNICODE);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? '');
        $apellido = trim($data['apellido'] ?? '');
        $correo = trim($data['correo'] ?? '');
        $password = trim($data['password'] ?? '');
        $telefono = trim($data['telefono'] ?? '');
        $id_rol = intval($data['id_rol'] ?? 0);
        $activo = isset($data['activo']) ? intval((bool)$data['activo']) : 1;

        if ($nombre === '' || $apellido === '' || $correo === '' || $password === '' || $id_rol <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Nombre, apellido, correo, password e id_rol son obligatorios"), JSON_UNESCAPED_UNICODE);
            break;
        }
        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El formato del correo no es válido"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
        $stmt->bind_param("i", $id_rol);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El rol indicado no existe"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ?");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(array("mensaje" => "Ya existe un usuario con ese correo"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, telefono, id_rol, activo) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo);
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Usuario creado exitosamente", "id" => $conn->insert_id), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el usuario"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'PUT':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar el usuario"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? '');
        $apellido = trim($data['apellido'] ?? '');
        $correo = trim($data['correo'] ?? '');
        $password = trim($data['password'] ?? '');
        $telefono = trim($data['telefono'] ?? '');
        $id_rol = intval($data['id_rol'] ?? 0);
        $activo = isset($data['activo']) ? intval((bool)$data['activo']) : -1;

        if ($nombre === '' || $apellido === '' || $correo === '' || $password === '' || $id_rol <= 0 || $activo < 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Para PUT debes enviar todos los campos del usuario"), JSON_UNESCAPED_UNICODE);
            break;
        }
        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El formato del correo no es válido"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Usuario no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
        $stmt->bind_param("i", $id_rol);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El rol indicado no existe"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ? AND id <> ?");
        $stmt->bind_param("si", $correo, $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(array("mensaje" => "El correo ya está registrado por otro usuario"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ?, telefono = ?, id_rol = ?, activo = ? WHERE id = ?");
        $stmt->bind_param("sssssiii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo, $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Usuario actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el usuario"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'PATCH':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar el usuario"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        if (!is_array($data) || count($data) === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Debes enviar al menos un campo para actualizar"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Usuario no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $campos = array();
        $valores = array();
        $tipos = '';
        $permitidos = array('nombre', 'apellido', 'correo', 'password', 'telefono', 'id_rol', 'activo');

        foreach ($permitidos as $campo) {
            if (array_key_exists($campo, $data)) {
                $valor = $data[$campo];
                if (in_array($campo, array('nombre', 'apellido', 'correo', 'password')) && trim((string)$valor) === '') {
                    http_response_code(400);
                    echo json_encode(array("mensaje" => "El campo $campo no puede estar vacío"), JSON_UNESCAPED_UNICODE);
                    $conn->close();
                    exit;
                }
                if ($campo === 'correo' && !filter_var(trim($valor), FILTER_VALIDATE_EMAIL)) {
                    http_response_code(400);
                    echo json_encode(array("mensaje" => "El formato del correo no es válido"), JSON_UNESCAPED_UNICODE);
                    $conn->close();
                    exit;
                }
                if ($campo === 'id_rol') {
                    $valor = intval($valor);
                    $revision = $conn->prepare("SELECT id FROM roles WHERE id = ?");
                    $revision->bind_param("i", $valor);
                    $revision->execute();
                    if ($revision->get_result()->num_rows === 0) {
                        http_response_code(400);
                        echo json_encode(array("mensaje" => "El rol indicado no existe"), JSON_UNESCAPED_UNICODE);
                        $revision->close();
                        $conn->close();
                        exit;
                    }
                    $revision->close();
                }
                if ($campo === 'correo') {
                    $revision = $conn->prepare("SELECT id FROM usuarios WHERE correo = ? AND id <> ?");
                    $correo_revision = trim($valor);
                    $revision->bind_param("si", $correo_revision, $id);
                    $revision->execute();
                    if ($revision->get_result()->num_rows > 0) {
                        http_response_code(409);
                        echo json_encode(array("mensaje" => "El correo ya está registrado por otro usuario"), JSON_UNESCAPED_UNICODE);
                        $revision->close();
                        $conn->close();
                        exit;
                    }
                    $revision->close();
                    $valor = $correo_revision;
                }

                $campos[] = "$campo = ?";
                if ($campo === 'id_rol' || $campo === 'activo') {
                    $tipos .= 'i';
                    $valores[] = intval($valor);
                } else {
                    $tipos .= 's';
                    $valores[] = trim((string)$valor);
                }
            }
        }

        if (count($campos) === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "No se enviaron campos válidos"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $sql = "UPDATE usuarios SET " . implode(', ', $campos) . " WHERE id = ?";
        $tipos .= 'i';
        $valores[] = $id;
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($tipos, ...$valores);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Usuario actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el usuario"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'DELETE':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar el usuario"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Usuario no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id_usuario = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(array("mensaje" => "No se puede eliminar el usuario porque tiene préstamos registrados"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Usuario eliminado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al eliminar el usuario"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}
$conn->close();
