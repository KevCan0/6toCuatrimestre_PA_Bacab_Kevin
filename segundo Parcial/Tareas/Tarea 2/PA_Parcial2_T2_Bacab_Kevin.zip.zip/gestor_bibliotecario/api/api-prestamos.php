<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];
$estados_validos = array('prestado', 'devuelto', 'retrasado');

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc(), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Préstamo no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
        } elseif (isset($_GET['usuario'])) {
            $usuario = '%' . trim($_GET['usuario']) . '%';
            $stmt = $conn->prepare("SELECT prestamos.id, prestamos.id_usuario, usuarios.nombre, usuarios.apellido, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado FROM prestamos INNER JOIN usuarios ON prestamos.id_usuario = usuarios.id WHERE usuarios.nombre LIKE ? OR usuarios.apellido LIKE ? ORDER BY prestamos.id");
            $stmt->bind_param("ss", $usuario, $usuario);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();
            while ($row = $resultado->fetch_assoc()) { $prestamos[] = $row; }
            http_response_code(200);
            echo json_encode($prestamos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
        } elseif (isset($_GET['estado'])) {
            $estado = trim($_GET['estado']);
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE estado = ? ORDER BY id");
            $stmt->bind_param("s", $estado);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();
            while ($row = $resultado->fetch_assoc()) { $prestamos[] = $row; }
            http_response_code(200);
            echo json_encode($prestamos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
        } elseif (isset($_GET['atrasados']) && strtolower(trim($_GET['atrasados'])) === 'true') {
            $hoy = date('Y-m-d');
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE fecha_devolucion < ? AND estado <> 'devuelto' ORDER BY id");
            $stmt->bind_param("s", $hoy);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();
            while ($row = $resultado->fetch_assoc()) { $prestamos[] = $row; }
            http_response_code(200);
            echo json_encode($prestamos, JSON_UNESCAPED_UNICODE);
            $stmt->close();
        } else {
            $resultado = $conn->query("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos ORDER BY id");
            $prestamos = array();
            while ($row = $resultado->fetch_assoc()) { $prestamos[] = $row; }
            http_response_code(200);
            echo json_encode($prestamos, JSON_UNESCAPED_UNICODE);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $id_usuario = intval($data['id_usuario'] ?? 0);
        $fecha_prestamo = trim($data['fecha_prestamo'] ?? '');
        $fecha_devolucion = trim($data['fecha_devolucion'] ?? '');
        $estado = trim($data['estado'] ?? 'prestado');

        if ($id_usuario <= 0 || $fecha_prestamo === '' || $fecha_devolucion === '') {
            http_response_code(400);
            echo json_encode(array("mensaje" => "id_usuario, fecha_prestamo y fecha_devolucion son obligatorios"), JSON_UNESCAPED_UNICODE);
            break;
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_prestamo) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_devolucion)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Las fechas deben tener el formato AAAA-MM-DD"), JSON_UNESCAPED_UNICODE);
            break;
        }
        if ($fecha_devolucion < $fecha_prestamo) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "La fecha de devolución no puede ser anterior a la fecha del préstamo"), JSON_UNESCAPED_UNICODE);
            break;
        }
        if (!in_array($estado, $estados_validos)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Estado no válido"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El usuario indicado no existe"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO prestamos (id_usuario, fecha_prestamo, fecha_devolucion, estado) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado);
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Préstamo creado exitosamente", "id" => $conn->insert_id), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el préstamo"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'PUT':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar el préstamo"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        $id_usuario = intval($data['id_usuario'] ?? 0);
        $fecha_prestamo = trim($data['fecha_prestamo'] ?? '');
        $fecha_devolucion = trim($data['fecha_devolucion'] ?? '');
        $estado = trim($data['estado'] ?? '');

        if ($id_usuario <= 0 || $fecha_prestamo === '' || $fecha_devolucion === '' || $estado === '') {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Para PUT debes enviar todos los campos del préstamo"), JSON_UNESCAPED_UNICODE);
            break;
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_prestamo) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_devolucion) || $fecha_devolucion < $fecha_prestamo) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Revisa el formato y el orden de las fechas"), JSON_UNESCAPED_UNICODE);
            break;
        }
        if (!in_array($estado, $estados_validos)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Estado no válido"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Préstamo no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id_usuario);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El usuario indicado no existe"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("UPDATE prestamos SET id_usuario = ?, fecha_prestamo = ?, fecha_devolucion = ?, estado = ? WHERE id = ?");
        $stmt->bind_param("isssi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Préstamo actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el préstamo"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'PATCH':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar el préstamo"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        if (!is_array($data) || count($data) === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Debes enviar al menos un campo para actualizar"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id, fecha_prestamo, fecha_devolucion FROM prestamos WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        if ($resultado->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Préstamo no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $actual = $resultado->fetch_assoc();
        $stmt->close();

        $campos = array();
        $valores = array();
        $tipos = '';
        foreach (array('id_usuario', 'fecha_prestamo', 'fecha_devolucion', 'estado') as $campo) {
            if (array_key_exists($campo, $data)) {
                $valor = $data[$campo];
                if ($campo === 'id_usuario') {
                    $valor = intval($valor);
                    $revision = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
                    $revision->bind_param("i", $valor);
                    $revision->execute();
                    if ($valor <= 0 || $revision->get_result()->num_rows === 0) {
                        http_response_code(400);
                        echo json_encode(array("mensaje" => "El usuario indicado no existe"), JSON_UNESCAPED_UNICODE);
                        $revision->close();
                        $conn->close();
                        exit;
                    }
                    $revision->close();
                    $tipos .= 'i';
                } else {
                    $valor = trim((string)$valor);
                    if ($campo === 'estado' && !in_array($valor, $estados_validos)) {
                        http_response_code(400);
                        echo json_encode(array("mensaje" => "Estado no válido"), JSON_UNESCAPED_UNICODE);
                        $conn->close();
                        exit;
                    }
                    if (($campo === 'fecha_prestamo' || $campo === 'fecha_devolucion') && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $valor)) {
                        http_response_code(400);
                        echo json_encode(array("mensaje" => "Las fechas deben tener el formato AAAA-MM-DD"), JSON_UNESCAPED_UNICODE);
                        $conn->close();
                        exit;
                    }
                    $tipos .= 's';
                }
                $campos[] = "$campo = ?";
                $valores[] = $valor;
            }
        }
        if (count($campos) === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "No se enviaron campos válidos"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $nueva_fecha_prestamo = $data['fecha_prestamo'] ?? $actual['fecha_prestamo'];
        $nueva_fecha_devolucion = $data['fecha_devolucion'] ?? $actual['fecha_devolucion'];
        if ($nueva_fecha_devolucion < $nueva_fecha_prestamo) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "La fecha de devolución no puede ser anterior a la fecha del préstamo"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $sql = "UPDATE prestamos SET " . implode(', ', $campos) . " WHERE id = ?";
        $tipos .= 'i';
        $valores[] = $id;
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($tipos, ...$valores);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Préstamo actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el préstamo"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'DELETE':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar el préstamo"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Préstamo no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM prestamos WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Préstamo eliminado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al eliminar el préstamo"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}
$conn->close();
