<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre FROM roles WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc(), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Rol no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
        } else {
            $resultado = $conn->query("SELECT id, nombre FROM roles ORDER BY id");
            $roles = array();
            while ($row = $resultado->fetch_assoc()) {
                $roles[] = $row;
            }
            http_response_code(200);
            echo json_encode($roles, JSON_UNESCAPED_UNICODE);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? '');

        if ($nombre === '') {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre del rol es obligatorio"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM roles WHERE nombre = ?");
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(array("mensaje" => "Ya existe un rol con ese nombre"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO roles (nombre) VALUES (?)");
        $stmt->bind_param("s", $nombre);
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Rol creado exitosamente", "id" => $conn->insert_id), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el rol"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'PUT':
    case 'PATCH':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar el rol"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? '');

        if ($nombre === '') {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre del rol es obligatorio"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Rol no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id FROM roles WHERE nombre = ? AND id <> ?");
        $stmt->bind_param("si", $nombre, $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(array("mensaje" => "Ya existe otro rol con ese nombre"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("UPDATE roles SET nombre = ? WHERE id = ?");
        $stmt->bind_param("si", $nombre, $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Rol actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el rol"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'DELETE':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar el rol"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT id FROM roles WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Rol no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE id_rol = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(array("mensaje" => "No se puede eliminar el rol porque tiene usuarios asignados"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM roles WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Rol eliminado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al eliminar el rol"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}
$conn->close();
