<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc(), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Autor no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
        } elseif (isset($_GET['nombre']) || isset($_GET['apellido']) || isset($_GET['nacionalidad'])) {
            $campo = isset($_GET['nombre']) ? 'nombre' : (isset($_GET['apellido']) ? 'apellido' : 'nacionalidad');
            $valor = '%' . trim($_GET[$campo]) . '%';
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE $campo LIKE ? ORDER BY id");
            $stmt->bind_param("s", $valor);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();
            while ($row = $resultado->fetch_assoc()) { $autores[] = $row; }
            http_response_code(200);
            echo json_encode($autores, JSON_UNESCAPED_UNICODE);
            $stmt->close();
        } else {
            $resultado = $conn->query("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores ORDER BY id");
            $autores = array();
            while ($row = $resultado->fetch_assoc()) { $autores[] = $row; }
            http_response_code(200);
            echo json_encode($autores, JSON_UNESCAPED_UNICODE);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? '');
        $apellido = trim($data['apellido'] ?? '');
        $nacionalidad = trim($data['nacionalidad'] ?? '');
        $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? '');

        if ($nombre === '' || $apellido === '') {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre y el apellido son obligatorios"), JSON_UNESCAPED_UNICODE);
            break;
        }
        if ($fecha_nacimiento !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_nacimiento)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "La fecha de nacimiento debe tener el formato AAAA-MM-DD"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $fecha_nacimiento = $fecha_nacimiento === '' ? null : $fecha_nacimiento;

        $stmt = $conn->prepare("INSERT INTO autores (nombre, apellido, nacionalidad, fecha_nacimiento) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nombre, $apellido, $nacionalidad, $fecha_nacimiento);
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Autor creado exitosamente", "id" => $conn->insert_id), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el autor"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'PUT':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar el autor"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? '');
        $apellido = trim($data['apellido'] ?? '');
        $nacionalidad = trim($data['nacionalidad'] ?? '');
        $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? '');

        if ($nombre === '' || $apellido === '') {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre y el apellido son obligatorios"), JSON_UNESCAPED_UNICODE);
            break;
        }
        if ($fecha_nacimiento !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_nacimiento)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "La fecha de nacimiento debe tener el formato AAAA-MM-DD"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $fecha_nacimiento = $fecha_nacimiento === '' ? null : $fecha_nacimiento;

        $stmt = $conn->prepare("SELECT id FROM autores WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Autor no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("UPDATE autores SET nombre = ?, apellido = ?, nacionalidad = ?, fecha_nacimiento = ? WHERE id = ?");
        $stmt->bind_param("ssssi", $nombre, $apellido, $nacionalidad, $fecha_nacimiento, $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Autor actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el autor"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'PATCH':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar el autor"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        if (!is_array($data) || count($data) === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Debes enviar al menos un campo para actualizar"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM autores WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Autor no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $campos = array();
        $valores = array();
        foreach (array('nombre', 'apellido', 'nacionalidad', 'fecha_nacimiento') as $campo) {
            if (array_key_exists($campo, $data)) {
                $valor = trim((string)$data[$campo]);
                if (($campo === 'nombre' || $campo === 'apellido') && $valor === '') {
                    http_response_code(400);
                    echo json_encode(array("mensaje" => "El campo $campo no puede estar vacío"), JSON_UNESCAPED_UNICODE);
                    $conn->close();
                    exit;
                }
                if ($campo === 'fecha_nacimiento' && $valor !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $valor)) {
                    http_response_code(400);
                    echo json_encode(array("mensaje" => "La fecha de nacimiento debe tener el formato AAAA-MM-DD"), JSON_UNESCAPED_UNICODE);
                    $conn->close();
                    exit;
                }
                $campos[] = "$campo = ?";
                $valores[] = $valor === '' && $campo === 'fecha_nacimiento' ? null : $valor;
            }
        }
        if (count($campos) === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "No se enviaron campos válidos"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $sql = "UPDATE autores SET " . implode(', ', $campos) . " WHERE id = ?";
        $tipos = str_repeat('s', count($valores)) . 'i';
        $valores[] = $id;
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($tipos, ...$valores);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Autor actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el autor"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'DELETE':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar el autor"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT id FROM autores WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Autor no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM autores WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Autor eliminado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al eliminar el autor"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}
$conn->close();
