<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc(), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Detalle de préstamo no encontrado"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
        } elseif (isset($_GET['prestamo'])) {
            $id_prestamo = intval($_GET['prestamo']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_prestamo = ? ORDER BY id");
            $stmt->bind_param("i", $id_prestamo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();
            while ($row = $resultado->fetch_assoc()) { $detalles[] = $row; }
            http_response_code(200);
            echo json_encode($detalles, JSON_UNESCAPED_UNICODE);
            $stmt->close();
        } elseif (isset($_GET['libro']) || isset($_GET['id_libro'])) {
            $id_libro = intval($_GET['libro'] ?? $_GET['id_libro']);
            $con_libro = isset($_GET['con_libro']) && strtolower(trim($_GET['con_libro'])) === 'true';
            if ($con_libro) {
                $stmt = $conn->prepare("SELECT detalle_prestamo.id, detalle_prestamo.id_prestamo, detalle_prestamo.id_libro, detalle_prestamo.cantidad, libros.titulo, libros.isbn FROM detalle_prestamo INNER JOIN libros ON detalle_prestamo.id_libro = libros.id WHERE detalle_prestamo.id_libro = ? ORDER BY detalle_prestamo.id");
            } else {
                $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_libro = ? ORDER BY id");
            }
            $stmt->bind_param("i", $id_libro);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();
            while ($row = $resultado->fetch_assoc()) { $detalles[] = $row; }
            http_response_code(200);
            echo json_encode($detalles, JSON_UNESCAPED_UNICODE);
            $stmt->close();
        } else {
            $resultado = $conn->query("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo ORDER BY id");
            $detalles = array();
            while ($row = $resultado->fetch_assoc()) { $detalles[] = $row; }
            http_response_code(200);
            echo json_encode($detalles, JSON_UNESCAPED_UNICODE);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $id_prestamo = intval($data['id_prestamo'] ?? 0);
        $id_libro = intval($data['id_libro'] ?? 0);
        $cantidad = intval($data['cantidad'] ?? 0);

        if ($id_prestamo <= 0 || $id_libro <= 0 || $cantidad <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "id_prestamo, id_libro y una cantidad mayor a cero son obligatorios"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $stmt->bind_param("i", $id_prestamo);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El préstamo indicado no existe"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id, disponibles FROM libros WHERE id = ?");
        $stmt->bind_param("i", $id_libro);
        $stmt->execute();
        $resultado = $stmt->get_result();
        if ($resultado->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El libro indicado no existe"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $libro = $resultado->fetch_assoc();
        $stmt->close();

        if ($cantidad > intval($libro['disponibles'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "No hay suficientes ejemplares disponibles"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id_prestamo = ? AND id_libro = ?");
        $stmt->bind_param("ii", $id_prestamo, $id_libro);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            http_response_code(409);
            echo json_encode(array("mensaje" => "Ese libro ya fue agregado al préstamo"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro, cantidad) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $id_prestamo, $id_libro, $cantidad);
        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Detalle de préstamo agregado exitosamente", "id" => $conn->insert_id), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al agregar el detalle de préstamo"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'PUT':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar el detalle"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        $id_prestamo = intval($data['id_prestamo'] ?? 0);
        $id_libro = intval($data['id_libro'] ?? 0);
        $cantidad = intval($data['cantidad'] ?? 0);

        if ($id_prestamo <= 0 || $id_libro <= 0 || $cantidad <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Para PUT debes enviar id_prestamo, id_libro y cantidad"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Detalle de préstamo no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $stmt->bind_param("i", $id_prestamo);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El préstamo indicado no existe"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("SELECT id, disponibles FROM libros WHERE id = ?");
        $stmt->bind_param("i", $id_libro);
        $stmt->execute();
        $resultado = $stmt->get_result();
        if ($resultado->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El libro indicado no existe"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $libro = $resultado->fetch_assoc();
        $stmt->close();
        if ($cantidad > intval($libro['disponibles'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "No hay suficientes ejemplares disponibles"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("UPDATE detalle_prestamo SET id_prestamo = ?, id_libro = ?, cantidad = ? WHERE id = ?");
        $stmt->bind_param("iiii", $id_prestamo, $id_libro, $cantidad, $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Detalle de préstamo actualizado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el detalle"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'PATCH':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar la cantidad"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        $cantidad = intval($data['cantidad'] ?? 0);

        if ($cantidad <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "La cantidad debe ser mayor a cero"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("SELECT detalle_prestamo.id, detalle_prestamo.id_libro, libros.disponibles FROM detalle_prestamo INNER JOIN libros ON detalle_prestamo.id_libro = libros.id WHERE detalle_prestamo.id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        if ($resultado->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Detalle de préstamo no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $detalle = $resultado->fetch_assoc();
        $stmt->close();

        if ($cantidad > intval($detalle['disponibles'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "No hay suficientes ejemplares disponibles"), JSON_UNESCAPED_UNICODE);
            break;
        }

        $stmt = $conn->prepare("UPDATE detalle_prestamo SET cantidad = ? WHERE id = ?");
        $stmt->bind_param("ii", $cantidad, $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Cantidad actualizada exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar la cantidad"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    case 'DELETE':
        if (!isset($_GET['id']) || intval($_GET['id']) <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar el detalle"), JSON_UNESCAPED_UNICODE);
            break;
        }
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Detalle de préstamo no encontrado"), JSON_UNESCAPED_UNICODE);
            $stmt->close();
            break;
        }
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM detalle_prestamo WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Detalle de préstamo eliminado exitosamente"), JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al eliminar el detalle"), JSON_UNESCAPED_UNICODE);
        }
        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}
$conn->close();
