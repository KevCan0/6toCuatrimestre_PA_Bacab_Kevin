<?php
    $id = intval($_GET["id"] ?? 0);
    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
?>

<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Categoría</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div id="alert-container"></div>

<div class="card">
    <form id="categoria-edit-form" action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars((string) $id) ?>">

        <div class="form-group">
            <label><i class="fas fa-tag"></i> Nombre</label>
            <input id="nombre" type="text" name="nombre" value="" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Descripción</label>
            <textarea id="descripcion" name="descripcion"></textarea>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success" id="update-category-btn">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
