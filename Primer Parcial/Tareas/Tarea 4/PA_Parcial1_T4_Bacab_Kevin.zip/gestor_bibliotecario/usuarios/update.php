<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $id       = intval($_POST["id"] ?? 0);
    $nombre   = trim($_POST["nombre"] ?? "");
    $apellido = trim($_POST["apellido"] ?? "");
    $correo   = trim($_POST["correo"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $telefono = trim($_POST["telefono"] ?? "");
    $id_rol   = intval($_POST["id_rol"] ?? 0);
    $activo   = isset($_POST["activo"]) ? 1 : 0;

    if ($id <= 0 || $nombre === "" || $apellido === "" || $correo === "" || $id_rol <= 0) {
        header("Location: index.php?error=" . urlencode("Datos inválidos"));
        exit;
    }

    // Validar formato de correo
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        header("Location: edit.php?id=" . $id . "&error=" . urlencode("El correo no tiene un formato válido"));
        exit;
    }

    // Validar que el rol existe
    $stmt = $pdo->prepare("SELECT id FROM roles WHERE id = ?");
    $stmt->execute([$id_rol]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        header("Location: edit.php?id=" . $id . "&error=" . urlencode("El rol seleccionado no existe"));
        exit;
    }

    // Verificar que el correo no esté duplicado (excepto el del usuario actual)
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE correo = ? AND id != ?");
    $stmt->execute([$correo, $id]);
    if ($stmt->fetch(PDO::FETCH_ASSOC)) {
        header("Location: edit.php?id=" . $id . "&error=" . urlencode("El correo ya está registrado"));
        exit;
    }

    // Si se proporciona contraseña, actualizarla; si no, mantener la actual
    if (!empty($password)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ?, telefono = ?, id_rol = ?, activo = ? WHERE id = ?");
        $success = $stmt->execute([$nombre, $apellido, $correo, $password_hash, $telefono, $id_rol, $activo, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, telefono = ?, id_rol = ?, activo = ? WHERE id = ?");
        $success = $stmt->execute([$nombre, $apellido, $correo, $telefono, $id_rol, $activo, $id]);
    }

    if($success){
        header("Location: index.php?success=" . urlencode("Usuario actualizado exitosamente"));
        exit;
    }else{
        header("Location: index.php?error=" . urlencode("Error al actualizar el usuario"));
        exit;
    }
?>
