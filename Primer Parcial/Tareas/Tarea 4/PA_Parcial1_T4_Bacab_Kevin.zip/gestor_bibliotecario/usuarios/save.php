<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $nombre   = trim($_POST["nombre"] ?? "");
    $apellido = trim($_POST["apellido"] ?? "");
    $correo   = trim($_POST["correo"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $telefono = trim($_POST["telefono"] ?? "");
    $id_rol   = intval($_POST["id_rol"] ?? 0);

    if ($nombre === "" || $apellido === "" || $correo === "" || $password === "" || $id_rol <= 0) {
        header("Location: create.php?error=" . urlencode("El nombre, apellido, correo, contraseña y rol son obligatorios"));
        exit;
    }

    // Validar formato de correo
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        header("Location: create.php?error=" . urlencode("El correo no tiene un formato válido"));
        exit;
    }

    // Validar que el rol existe
    $stmt = $pdo->prepare("SELECT id FROM roles WHERE id = ?");
    $stmt->execute([$id_rol]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        header("Location: create.php?error=" . urlencode("El rol seleccionado no existe"));
        exit;
    }

    // Verificar que el correo no esté duplicado
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE correo = ?");
    $stmt->execute([$correo]);
    if ($stmt->fetch(PDO::FETCH_ASSOC)) {
        header("Location: create.php?error=" . urlencode("El correo ya está registrado"));
        exit;
    }

    // Encriptar contraseña
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, telefono, id_rol, fecha_registro) VALUES (?, ?, ?, ?, ?, ?, NOW())");

    if ($stmt->execute([$nombre, $apellido, $correo, $password_hash, $telefono, $id_rol])){
        header("Location: index.php?success=" . urlencode("Usuario creado exitosamente"));
        exit;
    } else{
        header("Location: create.php?error=" . urlencode("Error al crear el usuario"));
        exit;
    }
?>
