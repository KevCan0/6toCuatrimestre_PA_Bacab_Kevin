<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    try {
        // Iniciar transacción
        $pdo->beginTransaction();

        // Obtener detalles del préstamo para restaurar disponibilidad
        $stmt = $pdo->prepare("SELECT id_libro, cantidad FROM detalle_prestamo WHERE id_prestamo = ?");
        $stmt->execute([$id]);
        $detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Restaurar disponibilidad de libros
        foreach ($detalles as $detalle) {
            $stmt = $pdo->prepare("UPDATE libros SET disponibles = disponibles + ? WHERE id = ?");
            $stmt->execute([$detalle["cantidad"], $detalle["id_libro"]]);
        }

        // Eliminar detalles del préstamo
        $stmt = $pdo->prepare("DELETE FROM detalle_prestamo WHERE id_prestamo = ?");
        $stmt->execute([$id]);

        // Eliminar préstamo
        $stmt = $pdo->prepare("DELETE FROM prestamos WHERE id = ?");
        $stmt->execute([$id]);

        // Confirmar transacción
        $pdo->commit();

        header("Location: index.php?success=" . urlencode("Préstamo eliminado con éxito."));
        exit;
    } catch (Exception $e) {
        // Revertir transacción
        $pdo->rollBack();
        header("Location: index.php?error=" . urlencode("Error al eliminar el préstamo: " . $e->getMessage()));
        exit;
    }
?>
