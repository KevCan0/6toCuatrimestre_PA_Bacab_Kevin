<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $id               = intval($_POST["id"] ?? 0);
    $id_usuario       = intval($_POST["id_usuario"] ?? 0);
    $fecha_prestamo   = trim($_POST["fecha_prestamo"] ?? "");
    $fecha_devolucion = trim($_POST["fecha_devolucion"] ?? "");
    $estado           = trim($_POST["estado"] ?? "");

    if ($id <= 0 || $id_usuario <= 0 || empty($fecha_prestamo) || empty($fecha_devolucion) || empty($estado)) {
        header("Location: index.php?error=" . urlencode("Datos inválidos"));
        exit;
    }

    // Validar estado
    if (!in_array($estado, ["prestado", "devuelto", "retrasado"])) {
        header("Location: index.php?error=" . urlencode("Estado inválido"));
        exit;
    }

    // Validar fechas
    if (strtotime($fecha_prestamo) > strtotime($fecha_devolucion)) {
        header("Location: edit.php?id=" . $id . "&error=" . urlencode("La fecha de devolución debe ser posterior a la de préstamo"));
        exit;
    }

    // Validar usuario
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE id = ? AND activo = 1");
    $stmt->execute([$id_usuario]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        header("Location: edit.php?id=" . $id . "&error=" . urlencode("Usuario no válido o inactivo"));
        exit;
    }

    $stmt = $pdo->prepare("UPDATE prestamos SET id_usuario = ?, fecha_prestamo = ?, fecha_devolucion = ?, estado = ? WHERE id = ?");
    if($stmt->execute([$id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id])){
        header("Location: index.php?success=" . urlencode("Préstamo actualizado exitosamente"));
        exit;
    }else{
        header("Location: index.php?error=" . urlencode("Error al actualizar el préstamo"));
        exit;
    }
?>
