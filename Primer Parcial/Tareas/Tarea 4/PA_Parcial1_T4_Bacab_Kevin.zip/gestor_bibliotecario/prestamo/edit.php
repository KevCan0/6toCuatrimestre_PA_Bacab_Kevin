<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    $stmt = $pdo->prepare("SELECT p.*, CONCAT(u.nombre, ' ', u.apellido) as usuario_nombre FROM prestamos p LEFT JOIN usuarios u ON p.id_usuario = u.id WHERE p.id = ?");
    $stmt->execute([$id]);
    $prestamo = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$prestamo) {
        header("Location: index.php?error=" . urlencode("Préstamo no encontrado"));
        exit;
    }

    // Obtener detalles del préstamo
    $stmt = $pdo->prepare("SELECT dp.*, l.titulo FROM detalle_prestamo dp JOIN libros l ON dp.id_libro = l.id WHERE dp.id_prestamo = ?");
    $stmt->execute([$id]);
    $detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obtener usuarios
    $stmt = $pdo->query("SELECT id, CONCAT(nombre, ' ', apellido) as nombre_completo FROM usuarios WHERE activo = 1 ORDER BY nombre");
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Préstamo</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $prestamo["id"] ?>">

        <div class="form-group">
            <label><i class="fas fa-user"></i> Usuario</label>
            <select name="id_usuario" required>
                <option value="">-- Selecciona un usuario --</option>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario['id'] ?>" <?= $usuario['id'] == $prestamo['id_usuario'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($usuario['nombre_completo']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha Préstamo</label>
            <input type="date" name="fecha_prestamo" value="<?= $prestamo["fecha_prestamo"] ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha Devolución</label>
            <input type="date" name="fecha_devolucion" value="<?= $prestamo["fecha_devolucion"] ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-toggle-on"></i> Estado</label>
            <select name="estado" required>
                <option value="prestado" <?= $prestamo["estado"] == "prestado" ? 'selected' : '' ?>>Prestado</option>
                <option value="devuelto" <?= $prestamo["estado"] == "devuelto" ? 'selected' : '' ?>>Devuelto</option>
                <option value="retrasado" <?= $prestamo["estado"] == "retrasado" ? 'selected' : '' ?>>Retrasado</option>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-book"></i> Libros del Préstamo</label>
            <div style="border: 1px solid #ddd; padding: 10px; border-radius: 5px; background-color: #f9f9f9;">
                <?php foreach ($detalles as $detalle): ?>
                    <div style="padding: 8px; border-bottom: 1px solid #eee;">
                        <strong><?= htmlspecialchars($detalle["titulo"]) ?></strong> - Cantidad: <?= $detalle["cantidad"] ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <small style="color: #666;">Los detalles de los libros no se pueden modificar desde aquí.</small>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
