<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $id_usuario       = intval($_POST["id_usuario"] ?? 0);
    $fecha_prestamo   = trim($_POST["fecha_prestamo"] ?? "");
    $fecha_devolucion = trim($_POST["fecha_devolucion"] ?? "");
    $libros           = $_POST["libros"] ?? [];
    $cantidades       = $_POST["cantidades"] ?? [];

    if ($id_usuario <= 0 || empty($fecha_prestamo) || empty($fecha_devolucion) || empty($libros)) {
        header("Location: create.php?error=" . urlencode("Todos los campos son obligatorios"));
        exit;
    }

    // Validar fechas
    if (strtotime($fecha_prestamo) > strtotime($fecha_devolucion)) {
        header("Location: create.php?error=" . urlencode("La fecha de devolución debe ser posterior a la de préstamo"));
        exit;
    }

    // Validar usuario
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE id = ? AND activo = 1");
    $stmt->execute([$id_usuario]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        header("Location: create.php?error=" . urlencode("Usuario no válido o inactivo"));
        exit;
    }

    try {
        // Iniciar transacción
        $pdo->beginTransaction();

        // Insertar préstamo
        $stmt = $pdo->prepare("INSERT INTO prestamos (id_usuario, fecha_prestamo, fecha_devolucion, estado) VALUES (?, ?, ?, 'prestado')");
        $stmt->execute([$id_usuario, $fecha_prestamo, $fecha_devolucion]);
        $id_prestamo = $pdo->lastInsertId();

        // Insertar detalles del préstamo y actualizar disponibilidad
        foreach ($libros as $index => $id_libro) {
            $id_libro = intval($id_libro);
            $cantidad = intval($cantidades[$index] ?? 1);

            if ($id_libro <= 0 || $cantidad <= 0) {
                throw new Exception("Datos de libro inválidos");
            }

            // Verificar disponibilidad
            $stmt = $pdo->prepare("SELECT disponibles FROM libros WHERE id = ?");
            $stmt->execute([$id_libro]);
            $libro = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$libro || $libro["disponibles"] < $cantidad) {
                throw new Exception("No hay suficientes copias disponibles del libro");
            }

            // Insertar detalle
            $stmt = $pdo->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro, cantidad) VALUES (?, ?, ?)");
            $stmt->execute([$id_prestamo, $id_libro, $cantidad]);

            // Actualizar disponibles
            $stmt = $pdo->prepare("UPDATE libros SET disponibles = disponibles - ? WHERE id = ?");
            $stmt->execute([$cantidad, $id_libro]);
        }

        // Confirmar transacción
        $pdo->commit();
        
        header("Location: index.php?success=" . urlencode("Préstamo creado exitosamente"));
        exit;
    } catch (Exception $e) {
        // Revertir transacción
        $pdo->rollBack();
        header("Location: create.php?error=" . urlencode("Error al crear el préstamo: " . $e->getMessage()));
        exit;
    }
?>
