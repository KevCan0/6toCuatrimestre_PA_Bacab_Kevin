<?php
    require_once "../config/connection.php";

    // Obtener usuarios
    $stmt = $pdo->query("SELECT id, CONCAT(nombre, ' ', apellido) as nombre_completo FROM usuarios WHERE activo = 1 ORDER BY nombre");
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obtener libros disponibles
    $stmt = $pdo->query("SELECT l.id, l.titulo, l.disponibles, c.nombre as categoria FROM libros l JOIN categorias c ON l.id_categoria = c.id WHERE l.disponibles > 0 ORDER BY l.titulo");
    $libros = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nuevo Préstamo</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-user"></i> Usuario</label>
            <select name="id_usuario" required>
                <option value="">-- Selecciona un usuario --</option>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario['id'] ?>"><?= htmlspecialchars($usuario['nombre_completo']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha Préstamo</label>
            <input type="date" name="fecha_prestamo" value="<?= date('Y-m-d') ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha Devolución</label>
            <input type="date" name="fecha_devolucion" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-book"></i> Libros a Prestar</label>
            <div id="libros-container">
                <div class="libro-item" style="border: 1px solid #ddd; padding: 10px; margin: 10px 0; border-radius: 5px;">
                    <select name="libros[]" class="libro-select" required>
                        <option value="">-- Selecciona un libro --</option>
                        <?php foreach ($libros as $libro): ?>
                            <option value="<?= $libro['id'] ?>" data-disponibles="<?= $libro['disponibles'] ?>">
                                <?= htmlspecialchars($libro['titulo']) ?> (Disponibles: <?= $libro['disponibles'] ?>) - <?= htmlspecialchars($libro['categoria']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    
                    <input type="number" name="cantidades[]" min="1" placeholder="Cantidad" required style="margin-left: 10px; width: 100px;">
                    
                    <button type="button" class="btn btn-sm btn-danger remove-libro" style="margin-left: 10px;">
                        <i class="fas fa-trash"></i> Quitar
                    </button>
                </div>
            </div>
            <button type="button" class="btn btn-secondary btn-sm" onclick="agregarLibro()">
                <i class="fas fa-plus"></i> Agregar Libro
            </button>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar Préstamo
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<script>
function agregarLibro() {
    const container = document.getElementById('libros-container');
    const select = container.querySelector('.libro-select');
    
    const newItem = document.createElement('div');
    newItem.className = 'libro-item';
    newItem.style.border = '1px solid #ddd';
    newItem.style.padding = '10px';
    newItem.style.margin = '10px 0';
    newItem.style.borderRadius = '5px';
    
    newItem.innerHTML = `
        <select name="libros[]" class="libro-select" required>
            <option value="">-- Selecciona un libro --</option>
            <?php foreach ($libros as $libro): ?>
                <option value="<?= $libro['id'] ?>" data-disponibles="<?= $libro['disponibles'] ?>">
                    <?= htmlspecialchars($libro['titulo']) ?> (Disponibles: <?= $libro['disponibles'] ?>) - <?= htmlspecialchars($libro['categoria']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <input type="number" name="cantidades[]" min="1" placeholder="Cantidad" required style="margin-left: 10px; width: 100px;">
        
        <button type="button" class="btn btn-sm btn-danger remove-libro" style="margin-left: 10px;">
            <i class="fas fa-trash"></i> Quitar
        </button>
    `;
    
    container.appendChild(newItem);
    
    // Agregar evento al botón de eliminar
    newItem.querySelector('.remove-libro').addEventListener('click', function() {
        newItem.remove();
    });
}

// Agregar evento inicial a botones de eliminar
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.remove-libro').forEach(btn => {
        btn.addEventListener('click', function() {
            this.parentElement.remove();
        });
    });
});
</script>

<?php include_once "../includes/footer.php"; ?>
