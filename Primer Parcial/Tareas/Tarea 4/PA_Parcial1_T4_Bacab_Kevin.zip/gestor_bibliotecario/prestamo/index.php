<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    require_once "../config/connection.php";
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-book-reader"></i> Préstamos</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Préstamo
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Usuario</th>
                <th>Fecha Préstamo</th>
                <th>Fecha Devolución</th>
                <th>Estado</th>
                <th>Libros</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
                try {
                    $stmt = $pdo->query("SELECT p.*, CONCAT(u.nombre, ' ', u.apellido) as usuario_nombre FROM prestamos p LEFT JOIN usuarios u ON p.id_usuario = u.id ORDER BY p.id DESC");
                    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (Exception $e) {
                    echo "<tr><td colspan='7'><div class='alert alert-danger'>Error en la consulta: " . htmlspecialchars($e->getMessage()) . "</div></td></tr>";
                    $result = [];
                }
                if (count($result) > 0) {
                    foreach ($result as $row) {
                        // Contar libros en el préstamo
                        $stmt_libros = $pdo->prepare("SELECT COUNT(*) as cantidad FROM detalle_prestamo WHERE id_prestamo = ?");
                        $stmt_libros->execute([$row["id"]]);
                        $libros = $stmt_libros->fetch(PDO::FETCH_ASSOC)["cantidad"];
                        
                        // Determinar color del estado
                        $estado_class = "badge-secondary";
                        if ($row["estado"] == "prestado") $estado_class = "badge-info";
                        elseif ($row["estado"] == "devuelto") $estado_class = "badge-success";
                        elseif ($row["estado"] == "retrasado") $estado_class = "badge-danger";
                        
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["usuario_nombre"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["fecha_prestamo"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["fecha_devolucion"]) . "</td>";
                        echo "<td><span class='badge $estado_class'>" . htmlspecialchars($row["estado"]) . "</span></td>";
                        echo "<td>" . $libros . "</td>";
                        echo "<td>";
                        echo "<a href='edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Editar</a> ";
                        echo "<a href='delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger' onclick='return confirm(\"¿Estás seguro de que deseas eliminar este préstamo?\")'><i class='fas fa-trash'></i> Eliminar</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No se encontraron préstamos.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>
