const contenedor = document.getElementById("contenedor");
const boton = document.getElementById("btnPerros");

async function cargarPerros() {

    contenedor.innerHTML = "<p>Cargando imágenes...</p>";

    try {

        const respuesta = await fetch(
            "https://dog.ceo/api/breeds/image/random/6"
        );

        const datos = await respuesta.json();

        contenedor.innerHTML = "";

        datos.message.forEach(imagenURL => {

            let partes = imagenURL.split("/");

            let raza = partes[4];

            const tarjeta = document.createElement("div");
            tarjeta.classList.add("tarjeta");

            tarjeta.innerHTML = `
                <img src="${imagenURL}" alt="Perro">
                <div class="info">
                    Raza: ${raza}
                </div>
            `;

            contenedor.appendChild(tarjeta);

        });

    } catch (error) {

        contenedor.innerHTML =
            "<p>Error al cargar las imágenes.</p>";

        console.log(error);
    }
}

boton.addEventListener("click", cargarPerros);

cargarPerros();