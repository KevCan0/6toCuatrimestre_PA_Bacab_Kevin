<?php
    require_once "../config/connection.php";
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-book"></i> Libros</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Libro
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Título</th>
                <th>ISBN</th>
                <th>Categoría</th>
                <th>Año</th>
                <th>Editorial</th>
                <th>Cantidad</th>
                <th>Disponibles</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $stmt = $pdo->query("SELECT l.id, l.titulo, l.isbn, c.nombre AS categoria, l.anio_publicacion AS anio, l.editorial, l.cantidad, l.disponibles FROM libros l JOIN categorias c ON l.id_categoria = c.id ORDER BY l.id DESC");
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (count($result) > 0) {
                foreach ($result as $libro) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($libro["id"]) . "</td>";
                    echo "<td>" . htmlspecialchars($libro["titulo"]) . "</td>";
                    echo "<td>" . htmlspecialchars($libro["isbn"]) . "</td>";
                    echo "<td>" . htmlspecialchars($libro["categoria"]) . "</td>";
                    echo "<td>" . htmlspecialchars($libro["anio"]) . "</td>";
                    echo "<td>" . htmlspecialchars($libro["editorial"]) . "</td>";
                    echo "<td>" . htmlspecialchars($libro["cantidad"]) . "</td>";
                    echo "<td>" . htmlspecialchars($libro["disponibles"]) . "</td>";
                    echo "<td>";
                    echo "<a href='edit.php?id=" . urlencode($libro["id"]) . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Editar</a>";
                    echo "<br>";
                    echo "<br>";
                    echo "<a href='delete.php?id=" . urlencode($libro["id"]) . "' class='btn btn-sm btn-danger' onclick='return confirm(\"¿Estás seguro de que deseas eliminar este libro?\")'><i class='fas fa-trash'></i> Eliminar</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='9'>No se encontraron libros.</td></tr>";
            }
    
            ?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>
