<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    // Eliminar el libro
    $stmt = $pdo->prepare("DELETE FROM libro_autor WHERE id_libro = ?");
    $stmt->execute([$id]);

    $stmt = $pdo->prepare("DELETE FROM libros WHERE id = ?");
    if ($stmt->execute([$id])) {
        header("Location: index.php?success=" . urlencode("Libro eliminado exitosamente"));
    } else {
        header("Location: index.php?error=" . urlencode("Error al eliminar el libro"));
    }
?>
