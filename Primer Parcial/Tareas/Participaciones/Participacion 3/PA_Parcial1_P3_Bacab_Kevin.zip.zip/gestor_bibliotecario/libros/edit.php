<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    // Obtener el libro
    $stmt = $pdo->prepare("SELECT * FROM libros WHERE id = ?");
    $stmt->execute([$id]);
    $libro = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$libro) {
        header("Location: index.php?error=" . urlencode("Libro no encontrado"));
        exit;
    }

    // Obtener los autores asignados al libro
    $stmt = $pdo->prepare("SELECT id_autor FROM libro_autor WHERE id_libro = ?");
    $stmt->execute([$id]);
    $libro_autores = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Obtener todas las categorías
    $stmt = $pdo->query("SELECT id, nombre FROM categorias ORDER BY nombre");
    $categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Obtener todos los autores
    $stmt = $pdo->query("SELECT id, nombre, apellido FROM autores ORDER BY nombre");
    $autores = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-book-open"></i> Editar Libro</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $libro["id"] ?? $id ?>">

        <div class="form-group">
            <label><i class="fas fa-book"></i> Título</label>
            <input type="text" name="titulo" value="<?= htmlspecialchars($libro["titulo"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-barcode"></i> ISBN</label>
            <input type="text" name="isbn" value="<?= htmlspecialchars($libro["isbn"] ?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Año de Publicación</label>
            <input type="number" name="anio_publicacion" value="<?= $libro["anio_publicacion"] ?? "" ?>" min="1000" max="<?= date('Y') ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-building"></i> Editorial</label>
            <input type="text" name="editorial" value="<?= htmlspecialchars($libro["editorial"] ?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-cubes"></i> Cantidad</label>
            <input type="number" name="cantidad" value="<?= $libro["cantidad"] ?? 0 ?>" min="0">
        </div>

        <div class="form-group">
            <label><i class="fas fa-check-circle"></i> Disponibles</label>
            <input type="number" name="disponibles" value="<?= $libro["disponibles"] ?? 0 ?>" min="0">
        </div>

        <div class="form-group">
            <label><i class="fas fa-tag"></i> Categoría</label>
            <select name="id_categoria" required>
                <option value="">-- Selecciona una categoría --</option>
                <?php foreach ($categorias as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= $libro['id_categoria'] == $cat['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($cat['nombre']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Autor(es)</label>
            <select name="id_autores[]" multiple required>
                <?php foreach ($autores as $autor): ?>
                    <option value="<?= $autor['id'] ?>" <?= in_array($autor['id'], $libro_autores) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($autor['nombre'] . ' ' . $autor['apellido']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <small>Mantén Ctrl (o Cmd) para seleccionar varios autores</small>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
