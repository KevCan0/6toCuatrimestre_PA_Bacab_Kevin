<?php
    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "";
    $db_name = "gestor_biblioteca";

    try {
        $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("SET NAMES utf8");
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
    ?>
