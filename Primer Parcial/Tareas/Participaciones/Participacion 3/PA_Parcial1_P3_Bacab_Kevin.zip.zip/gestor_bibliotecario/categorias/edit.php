<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if($id > 0){
        $stmt = $pdo->prepare("SELECT id, nombre, descripcion FROM categorias WHERE id = ?");
        $stmt->execute([$id]);
        $categoria = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$categoria) {
            header("Location: index.php?error=" . urlencode("Categoría no encontrada"));
            exit;
        }
    }else{
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
?>

<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-edit"></i> Editar Categoría</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $categoria["id"] ?? $id ?>">

        <div class="form-group">
            <label><i class="fas fa-tag"></i> Nombre</label>
            <input type="text" name="nombre" value="<?= htmlspecialchars($categoria["nombre"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Descripción</label>
            <textarea name="descripcion"><?= htmlspecialchars($categoria["descripcion"] ?? "") ?></textarea>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
