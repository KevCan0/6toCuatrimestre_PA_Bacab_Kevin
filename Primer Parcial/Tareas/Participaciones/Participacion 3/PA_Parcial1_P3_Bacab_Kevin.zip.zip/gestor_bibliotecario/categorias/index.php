<?php
    require_once "../config/connection.php"; // Incluimos la conexión a la base de datos
?>
<?php include_once "../includes/header.php"; // Incluimos el encabezado. Básicamente lo que hace esto es que el archivo header.php se incrusta en mi archivo actual, el archivo header.php ya contiene el código HTML del encabezado, lo que me permitirá reutilizarlo cuantas veces sea necesario?> 

<div class="page-header">
    <h1><i class="fas fa-tags"></i> Categorías</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nueva Categoría
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $stmt = $pdo->query("SELECT id, nombre, descripcion FROM categorias");
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach($result as $row){
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["nombre"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["descripcion"]) . "</td>";
                    echo "<td>";
                    echo "<a href='edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Editar</a>";
                    echo "<a href='delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger'><i class='fas fa-trash'></i> Eliminar</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            ?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>
