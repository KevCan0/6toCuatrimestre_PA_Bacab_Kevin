<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    // Eliminar la categoría
    $stmt = $pdo->prepare("DELETE FROM categorias WHERE id = ?");
    if($stmt->execute([$id])){
        header("Location: index.php?success=" . urlencode("Categoría eliminada con éxito."));
        exit;
    }else{
        header("Location: index.php?error=" . urlencode("Error al eliminar la categoría"));
        exit;
    }
?>
