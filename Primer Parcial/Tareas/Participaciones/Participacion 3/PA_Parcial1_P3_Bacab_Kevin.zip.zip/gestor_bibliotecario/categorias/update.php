<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $id = intval($_POST["id"] ?? 0); 
    $nombre = trim($_POST["nombre"] ?? "");
    $descripcion = trim($_POST["descripcion"] ?? "");

    if ($id <= 0 || $nombre === "") {
        header("Location: index.php?error=" . urlencode("Datos inválidos"));
        exit;
    }

    // Actualizar la categoría
    $stmt = $pdo->prepare("UPDATE categorias SET nombre = ?, descripcion = ? WHERE id = ?");
    if($stmt->execute([$nombre, $descripcion, $id])){
        header("Location: index.php?success=" . urlencode("Categoría actualizada exitosamente"));
        exit;
    }else{
        header("Location: index.php?error=" . urlencode("Error al actualizar la categoría"));
        exit;
    }
?>
