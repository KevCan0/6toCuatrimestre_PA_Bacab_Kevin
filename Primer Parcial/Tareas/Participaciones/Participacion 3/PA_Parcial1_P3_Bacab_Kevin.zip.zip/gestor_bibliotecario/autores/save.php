<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $nombre           = trim($_POST["nombre"] ?? "");
    $apellido         = trim($_POST["apellido"] ?? "");
    $nacionalidad     = trim($_POST["nacionalidad"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "") ?: null;

    if ($nombre === "" || $apellido === "") {
        header("Location: create.php?error=" . urlencode("El nombre y apellido son obligatorios"));
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO autores (nombre, apellido, nacionalidad, fecha_nacimiento) VALUES (?, ?, ?, ?)");

    if ($stmt->execute([$nombre, $apellido, $nacionalidad, $fecha_nacimiento])){
        header("Location: index.php?success=" . urlencode("Autor creado exitosamente"));
        exit;
    } else{
        header("Location: create.php?error=" . urlencode("Error al crear el autor"));
        exit;
    }
?>
