<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
    $stmt = $pdo->prepare("DELETE FROM autores WHERE id = ?");
    if($stmt->execute([$id])){
        header("Location: index.php?success=" . urlencode("Autor eliminado con éxito."));
        exit;
    }else{
        header("Location: index.php?error=" . urlencode("Error al eliminar el autor"));
        exit;
    }
?>
