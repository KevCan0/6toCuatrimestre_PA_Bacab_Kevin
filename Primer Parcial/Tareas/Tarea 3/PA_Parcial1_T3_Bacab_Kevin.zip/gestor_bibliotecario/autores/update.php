<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $id               = intval($_POST["id"] ?? 0);
    $nombre           = trim($_POST["nombre"] ?? "");
    $apellido         = trim($_POST["apellido"] ?? "");
    $nacionalidad     = trim($_POST["nacionalidad"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "") ?: null;

    if ($id <= 0 || $nombre === "" || $apellido === "") {
        header("Location: index.php?error=" . urlencode("Datos inválidos"));
        exit;
    }

    $stmt = $conn->prepare("UPDATE autores SET nombre = ?, apellido = ?, nacionalidad = ?, fecha_nacimiento = ? WHERE id = ?"); // Aquí hacemos una consulta preparada utilizando UPDATE para actualizar los datos del autor. Los signos "?" son marcadores de posición para los valores que se pasarán posteriormente.
    $stmt->bind_param("ssssi", $nombre, $apellido, $nacionalidad, $fecha_nacimiento, $id); // Aquí le pasamos los valores de los marcadores de posición a nuestra consulta previamente preparada. "ssssi".
    if($stmt->execute()){// Aquí ejecutamos la consulta preparada
        header("Location:index.php?success=" . urlencode("Autor actualizado exitosamente"));// si la ejecución es exitosa, redirigimos al usuario a la página de listado de autores con un mensaje de éxito
        exit;// Detenemos la ejecución del script después de redirigir al usuario
    }else{
        header("Location: index.php?error=" .urlencode("Error al actualizar el autor: " . $stmt->error));// Si ocurre un error al ejecutar la consulta, redirigimos al usuario a la página de listado de autores con un mensaje de error. $stmt->error contiene el mensaje de error específico que ocurrió
        exit;
    }
    $stmt->close(); // Cerramos la consulta preparada
    $conn->close(); // Cerramos la conexión a la base de datos
?>
