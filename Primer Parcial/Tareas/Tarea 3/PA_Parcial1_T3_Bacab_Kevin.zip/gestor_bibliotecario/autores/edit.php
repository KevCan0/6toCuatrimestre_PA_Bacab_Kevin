<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
    if($id > 0){// Si el ID es válido, procedemos a obtener los datos del autor para mostrar en el formulario de edición
        $stmt = $conn->prepare("SELECT * FROM autores WHERE id = ?"); // Nuestra consulta preparada es un SELECT en el cual obtendremos los datos según el ID que recibimos por la URL. Recordemos que el signo de interrogación (?) es un marcador de posición para el valor que se pasará posteriormente.
        $stmt->bind_param("i", $id); // Lo que hacemos es decirle a la consulta que el marcador de posición es un número entero (i) y que el valor que pasará es el de la variable $id.
        $stmt->execute(); // Ejecutamos la consulta preparada.
        $result = $stmt->get_result(); // Obtenemos el resultado de la consulta
        $autor = $result->fetch_assoc(); // Obtenemos la fila del resultado como un array asociativo y lo almacenamos en la variable $autor.
        $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
        $conn->close(); // Cerramos la conexión a la base de datos para liberar recursos
    }else{
        header("Location: index.php?error=" . urlencode("ID inválido"));// Si el ID no es válido, redirigimos al usuario a la página de listado de autores con un mensaje de error
        exit;
    }

?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-user-edit"></i> Editar Autor</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $autor["id"] ?? $id ?>">

        <div class="form-group">
            <label><i class="fas fa-user"></i> Nombre</label>
            <input type="text" name="nombre" value="<?= htmlspecialchars($autor["nombre"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Apellido</label>
            <input type="text" name="apellido" value="<?= htmlspecialchars($autor["apellido"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-globe"></i> Nacionalidad</label>
            <input type="text" name="nacionalidad" value="<?= htmlspecialchars($autor["nacionalidad"] ?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha de Nacimiento</label>
            <input type="date" name="fecha_nacimiento" value="<?= $autor["fecha_nacimiento"] ?? "" ?>">
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
