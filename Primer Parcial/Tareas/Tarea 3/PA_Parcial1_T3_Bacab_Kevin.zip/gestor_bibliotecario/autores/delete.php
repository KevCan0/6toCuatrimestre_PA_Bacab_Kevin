<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
    $stmt = $conn->prepare("DELETE FROM autores WHERE id = ?"); // Aquí hacemos una consulta preparada utilizando DELETE para eliminar el autor según el ID que recibimos por la URL. El signo "?" es un marcador de posición para el valor que se pasará posteriormente.
    $stmt->bind_param("i", $id); // Aquí le pasamos el valor del marcador de posición a nuestra consulta previamente preparada. "i" indica que el valor es un número entero y $id es la variable que contiene el valor que se pasará a la consulta.
    if($stmt->execute()){// Aquí ejecutamos la consulta preparada
        header("Location: index.php?success=" . urlencode("Autor eliminado con éxito."));// si la ejecución es exitosa, redirigimos al usuario a la página de listado de autores con un mensaje de éxito
        exit; // Detenemos la ejecución del script después de redirigir al usuario
    }else{// Si ocurre un error al ejecutar la consulta, redirigimos al usuario a la página de listado de autores con un mensaje de error   
        header("Location: index.php?error=" . urlencode("Error al eliminar el autor: " . $stmt->error));// $stmt->error contiene el mensaje de error específico que ocurrió durante la ejecución
        exit;
    }
?>
