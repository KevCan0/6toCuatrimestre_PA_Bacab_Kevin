<?php
    require_once "../config/connection.php";
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-users"></i> Autores</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Autor
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Nacionalidad</th>
                <th>Fecha de Nacimiento</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $stmt = $conn->prepare("SELECT * FROM autores"); // En esta linea de codigo, se define una consulta SQL para selecciona los registros de la tabla autores. El asterisco (*) se utiliza para indicar que se seleccionarán todas las columnas de la tabla.
                $stmt->execute();// Aquí se ejecuta la consulta preparada utilizando el método execute() del objeto $stmt.
                $result = $stmt->get_result();// Después de ejecutar la consulta, se obtiene el resultado utilizando el método get_result() del objeto $stmt. Este método devuelve un objeto que representa el conjunto de resultados de la consulta.
                if ($result->num_rows > 0) { // Aquí se verifica si el número de filas en el resultado es mayor que cero utilizando la propiedad num_rows del objeto $result. Si hay filas disponibles, se procede a iterar sobre ellas utilizando un bucle while.
                    while ($row = $result->fetch_assoc()) {// Dentro del bucle while, se utiliza el método fetch_assoc() del objeto $result para obtener cada fila del resultado como un array asociativo. Cada vez que se llama a fetch_assoc(), se devuelve la siguiente fila del resultado hasta que no haya más filas disponibles.
                        echo "<tr>"; // se inicia una nueva fila en la tabla HTML utilizando la etiqueta <tr>.
                        echo "<td>" . htmlspecialchars($row["id"]) . "</td>";// Aquí se muestra el valor de la columna id de la fila actual utilizando $row["id"]. La función htmlspecialchars() se utiliza para convertir caracteres especiales en entidades HTML, lo que ayuda a prevenir ataques de inyección de código.
                        echo "<td>" . htmlspecialchars($row["nombre"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["apellido"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["nacionalidad"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["fecha_nacimiento"]) . "</td>";
                        echo "<td>";
                        echo "<a href='edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Editar</a> ";// Aquí se genera un enlace para editar el autor, pasando el ID del autor como parámetro en la URL. La función urlencode() se utiliza para codificar el valor del ID para que sea seguro incluirlo en la URL.
                        echo "<a href='delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger' onclick='return confirm(\"¿Estás seguro de que deseas eliminar este autor?\")'><i class='fas fa-trash'></i> Eliminar</a>";// Aquí se genera un enlace para eliminar el autor, pasando el ID del autor como parámetro en la URL. Se agrega un evento onclick que muestra una confirmación antes de proceder
                        echo "</td>";
                        echo "</tr>";
                    }
                    $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
                    $conn->close(); // Cerramos la conexión a la base de datos para liberar recursos.
                } else {
                    echo "<tr><td colspan='6'>No se encontraron autores.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>
